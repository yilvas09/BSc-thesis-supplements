To perform comparative static analysis in mean-reverting markets for each parameter:
	Batch_E_MRV.m : comparative statics for exit sunk cost, E
	Batch_eta_MRV.m : comparative statics for reverting speed, eta
	Batch_I_MRV.m : comparative statics for entry sunk cost, I
	Batch_n_MRV.m : comparative statics for number of active firms, n
	Batch_ph_MRV.m : comparative statics for fixed operating cost, phi_i
	Batch_sgm_MRV.m : comparative statics for volatility rate of market size, sigma
	Batch_tht_st_MRV.m : comparative statics for mean market size, theta^*

To perform additional numerical experiments discussed in appendix:
	Experiment_1.m : replicate oligopoly effect
	Experiment_2.m : replicate dilution effect

To replicate figure that plots entry and exit thresholds under different numbers of active firms:
	Plot_Threshold_MRV.m

To replicate figure that plots value functions under different numbers of active firms:
	Plot_Value_functions_MRV.m

To replicate figure that plots systematic risk loadings of incumbents under different numbers of active firms:
	Plot_Betas_MRV.m